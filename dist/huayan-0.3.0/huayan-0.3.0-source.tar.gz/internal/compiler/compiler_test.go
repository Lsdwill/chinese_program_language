package compiler

import (
	"huayan/internal/ast"
	"huayan/internal/lexer"
	"huayan/internal/parser"
	"huayan/internal/source"
	"testing"
)

func compileTest(t *testing.T, text string) *ast.Program {
	t.Helper()
	f := &source.File{Name: "compiler.hua", Text: text}
	ts, le := lexer.Lex(f)
	if len(le) != 0 {
		t.Fatal(le)
	}
	p, pe := parser.Parse(ts)
	if len(pe) != 0 {
		t.Fatal(pe)
	}
	ch, ce := Compile(p)
	if len(ce) != 0 {
		t.Fatal(ce)
	}
	if err := ch.Validate(); err != nil {
		t.Fatal(err)
	}
	return p
}

func TestCompilerAllStatementForms(t *testing.T) {
	compileTest(t, `
模块 示例.主
公开 常量 版本 = 1
让 值 = [1, 2]
函数 运行(参数)
    让 局部 = 参数
    如果 局部 > 0
        返回 局部
    否则如果 局部 == 0
        返回 0
    否则
        返回 -局部
    结束
结束
当 假
    跳出
结束
遍历 项 于 值
    继续
结束
尝试
    抛出 错误("x")
捕获 原因
    打印(原因)
结束
运行(1)
`)
}

func TestCompilerResolverDiagnostics(t *testing.T) {
	f := &source.File{Name: "bad.hua", Text: "打印(未声明)\n返回 1\n跳出"}
	ts, _ := lexer.Lex(f)
	p, _ := parser.Parse(ts)
	_, ds := Compile(p)
	if len(ds) < 3 {
		t.Fatalf("diagnostics=%v", ds)
	}
	if _, ds = CompileREPL(p, map[string]bool{"未声明": true}); len(ds) == 0 {
		t.Fatal("REPL globals were ignored")
	}
}

func TestCompilerREPLExpression(t *testing.T) {
	f := &source.File{Name: "repl", Text: "1 + 2"}
	ts, _ := lexer.Lex(f)
	p, _ := parser.Parse(ts)
	ch, ds := CompileREPL(p, nil)
	if len(ds) != 0 || ch == nil || len(ch.Code) == 0 {
		t.Fatalf("chunk=%v diagnostics=%v", ch, ds)
	}
}

func TestCompilerAcceptsREPLGlobalsAndRejectsInvalidTargets(t *testing.T) {
	f := &source.File{Name: "repl", Text: "旧名 + 1"}
	ts, _ := lexer.Lex(f)
	p, _ := parser.Parse(ts)
	if _, ds := CompileREPL(p, map[string]bool{"旧名": true}); len(ds) != 0 {
		t.Fatalf("REPL global rejected: %v", ds)
	}
	f = &source.File{Name: "target", Text: "1 = 2"}
	ts, _ = lexer.Lex(f)
	p, _ = parser.Parse(ts)
	if _, ds := Compile(p); len(ds) == 0 {
		t.Fatal("invalid assignment target accepted")
	}
}
