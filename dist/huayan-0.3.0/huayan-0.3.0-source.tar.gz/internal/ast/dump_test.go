package ast_test

import (
	"huayan/internal/ast"
	"huayan/internal/lexer"
	"huayan/internal/parser"
	"huayan/internal/source"
	"strings"
	"testing"
)

func TestDumpStable(t *testing.T) {
	f := &source.File{Name: "golden.hua", Text: "让 数字 = 1 + 2\n打印(数字)"}
	ts, le := lexer.Lex(f)
	if len(le) != 0 {
		t.Fatal(le)
	}
	p, pe := parser.Parse(ts)
	if len(pe) != 0 {
		t.Fatal(pe)
	}
	want := "程序\n  变量 数字\n    变量值\n      二元 +\n        字面量 int 1\n        字面量 int 2\n  表达式\n    调用\n      名称 打印\n      名称 数字\n"
	if got := ast.Dump(p); got != want {
		t.Fatalf("dump mismatch:\n%s", strings.ReplaceAll(got, "\n", "\\n\n"))
	}
}
