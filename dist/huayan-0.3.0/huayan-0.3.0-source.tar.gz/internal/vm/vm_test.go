package vm

import (
	"bytes"
	"encoding/json"
	"huayan/internal/compiler"
	"huayan/internal/lexer"
	"huayan/internal/parser"
	"huayan/internal/source"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func runVMText(t *testing.T, text string) (string, *RuntimeError) {
	t.Helper()
	f := &source.File{Name: "vm-test.hua", Text: text}
	ts, le := lexer.Lex(f)
	if len(le) != 0 {
		t.Fatalf("lex: %v", le)
	}
	p, pe := parser.Parse(ts)
	if len(pe) != 0 {
		t.Fatalf("parse: %v", pe)
	}
	ch, ce := compiler.Compile(p)
	if len(ce) != 0 {
		t.Fatalf("compile: %v", ce)
	}
	var out bytes.Buffer
	v := New(&out, strings.NewReader(""), nil)
	_, re := v.Execute(ch, v.Globals())
	return out.String(), re
}

func TestVMControlFlowAndCollections(t *testing.T) {
	got, re := runVMText(t, `
让 总和 = 0
让 n = 0
当 n < 5
    n = n + 1
    如果 n == 2
        继续
    结束
    总和 = 总和 + n
结束
让 xs = [1, 2]
xs.追加(3)
让 d = {"a": 1}
d["b"] = 2
让 r = 记录 {名: "华言"}
r.年龄 = 3
遍历 项 于 xs
    总和 = 总和 + 项
结束
打印(总和)
打印(d["b"])
打印(r.名)
`)
	if re != nil {
		t.Fatal(re)
	}
	if got != "19\n2\n华言\n" {
		t.Fatalf("got %q", got)
	}
}

func TestVMClosureAndErrors(t *testing.T) {
	got, re := runVMText(t, `
函数 创建()
    让 值 = 0
    函数 增加()
        值 = 值 + 1
        返回 值
    结束
    返回 增加
结束
让 f = 创建()
打印(f())
打印(f())
尝试
    抛出 错误("测试")
捕获 原因
    打印(原因.消息)
结束
`)
	if re != nil {
		t.Fatal(re)
	}
	if got != "1\n2\n测试\n" {
		t.Fatalf("got %q", got)
	}
	_, re = runVMText(t, "常量 x = 1\nx = 2")
	if re == nil || !strings.Contains(re.Error(), "常量") {
		t.Fatal("constant assignment did not fail")
	}
}

func TestUpvalueClosesAfterFunctionReturns(t *testing.T) {
	f := &source.File{Name: "close.hua", Text: "函数 创建()\n让 n = 0\n函数 增加()\nn = n + 1\n返回 n\n结束\n返回 增加\n结束\n让 f = 创建()"}
	ts, _ := lexer.Lex(f)
	p, _ := parser.Parse(ts)
	ch, ds := compiler.Compile(p)
	if len(ds) != 0 {
		t.Fatal(ds)
	}
	v := New(&bytes.Buffer{}, strings.NewReader(""), nil)
	if _, re := v.Execute(ch, v.Globals()); re != nil {
		t.Fatal(re)
	}
	value, ok := v.Globals().Get("f")
	if !ok {
		t.Fatal("closure missing")
	}
	fn := value.Data.(*FunctionObject)
	if len(fn.Upvalues) != 1 || fn.Upvalues[0].env != nil || fn.Upvalues[0].closed.Data.(int64) != 0 {
		t.Fatalf("upvalue not closed: %#v", fn.Upvalues)
	}
	if _, re := v.call(value, nil, source.Span{}); re != nil {
		t.Fatal(re)
	}
	if fn.Upvalues[0].closed.Data.(int64) != 1 {
		t.Fatalf("closed value not updated: %v", fn.Upvalues[0].closed)
	}
}

func TestVMStandardModules(t *testing.T) {
	got, re := runVMText(t, `
导入 标准.文字 为 文字
导入 标准.列表 为 列表
导入 标准.JSON 为 JSON
导入 标准.数学 为 数学
导入 标准.时间 为 时间
函数 大于一(x)
    返回 x > 1
结束
打印(文字.长度("华😀"))
打印(列表.过滤([1, 2, 3], 大于一))
打印(JSON.序列化(记录 {甲: 1}))
打印(数学.绝对值(-3))
打印(时间.日期差("2026-01-01T00:00:00Z", "2026-01-01T00:00:02Z"))
`)
	if re != nil {
		t.Fatal(re)
	}
	if !strings.Contains(got, "2\n") || !strings.Contains(got, "[2, 3]") || !strings.Contains(got, "2\n") {
		t.Fatalf("got %q", got)
	}
}

func TestVMResourceLimitsAndMalformedInput(t *testing.T) {
	_, re := runVMText(t, "函数 f(n)\n返回 f(n + 1)\n结束\nf(0)")
	if re == nil {
		t.Fatal("expected call depth error")
	}
	var out bytes.Buffer
	v := New(&out, strings.NewReader(""), nil)
	v.MaxCallDepth = 2
	f := &source.File{Name: "limit.hua", Text: "函数 f(n)\n返回 f(n + 1)\n结束\nf(0)"}
	ts, _ := lexer.Lex(f)
	p, _ := parser.Parse(ts)
	ch, ds := compiler.Compile(p)
	if len(ds) != 0 {
		t.Fatal(ds)
	}
	if _, re := v.Execute(ch, v.Globals()); re == nil {
		t.Fatal("limit was not enforced")
	}
}

func TestJSONDepthLimit(t *testing.T) {
	text := strings.Repeat("[", 258) + strings.Repeat("]", 258)
	dec := json.NewDecoder(strings.NewReader(text))
	if _, err := decodeJSONValue(dec); err == nil || !strings.Contains(err.Error(), "嵌套层数") {
		t.Fatalf("err=%v", err)
	}
}

func callNativeForCoverage(t *testing.T, v *VM, mod Value, name string, args ...Value) (Value, *RuntimeError) {
	t.Helper()
	fn, ok := mod.Data.(*ModuleObject).Exports[name]
	if !ok {
		t.Fatalf("missing standard API %s", name)
	}
	return v.call(fn, args, source.Span{})
}

func TestStandardNativeAPIAndErrorBoundaries(t *testing.T) {
	v := New(&bytes.Buffer{}, strings.NewReader("输入行\n"), nil)
	text := func(s string) Value { return Text(s) }
	文字, _ := StandardModule("标准.文字", v)
	callNativeForCoverage(t, v, 文字, "查找", text("abc"), text("b"))
	callNativeForCoverage(t, v, 文字, "替换", text("abc"), text("b"), text("x"))
	callNativeForCoverage(t, v, 文字, "分割", text("a,b"), text(","))
	callNativeForCoverage(t, v, 文字, "裁剪", text(" a "))
	callNativeForCoverage(t, v, 文字, "大写", text("a"))
	callNativeForCoverage(t, v, 文字, "小写", text("A"))
	callNativeForCoverage(t, v, 文字, "长度", text("😀"))
	callNativeForCoverage(t, v, 文字, "查找", Int(1))
	列表, _ := StandardModule("标准.列表", v)
	items := List([]Value{Int(3), Int(1), Int(2)})
	callNativeForCoverage(t, v, 列表, "排序", items)
	callNativeForCoverage(t, v, 列表, "查找", items, Int(2))
	fn := v.native("加一", func(vm *VM, args []Value) (Value, *RuntimeError) {
		if len(args) == 0 {
			return Nil(), vm.fault("测试", "故意错误", source.Span{})
		}
		return Int(args[0].Data.(int64) + 1), nil
	})
	pred := v.native("大于一", func(_ *VM, args []Value) (Value, *RuntimeError) { return Bool(args[0].Data.(int64) > 1), nil })
	callNativeForCoverage(t, v, 列表, "映射", items, fn)
	callNativeForCoverage(t, v, 列表, "过滤", items, pred)
	字典, _ := StandardModule("标准.字典", v)
	d := Dict()
	setDict(d, text("a"), Int(1))
	callNativeForCoverage(t, v, 字典, "键", d)
	callNativeForCoverage(t, v, 字典, "值", d)
	callNativeForCoverage(t, v, 字典, "条目", d)
	callNativeForCoverage(t, v, 字典, "包含键", d, text("a"))
	callNativeForCoverage(t, v, 字典, "包含键", d, List(nil))
	tmp := t.TempDir()
	path := filepath.Join(tmp, "数据.txt")
	文件, _ := StandardModule("标准.文件", v)
	callNativeForCoverage(t, v, 文件, "创建目录", text(filepath.Join(tmp, "子目录")))
	callNativeForCoverage(t, v, 文件, "写入文字", text(path), text("a"))
	callNativeForCoverage(t, v, 文件, "追加文字", text(path), text("b"))
	callNativeForCoverage(t, v, 文件, "读取文字", text(path))
	callNativeForCoverage(t, v, 文件, "存在", text(path))
	callNativeForCoverage(t, v, 文件, "原子写入", text(path), text("c"))
	if _, err := os.Stat(path + ".bak"); err != nil {
		t.Fatalf("backup missing: %v", err)
	}
	batchItem := func(p, content string) Value {
		r := Record()
		o := r.Data.(*RecordObject)
		o.Order = []string{"路径", "内容"}
		o.Fields["路径"], o.Fields["内容"] = text(p), text(content)
		return r
	}
	batch := List([]Value{batchItem(filepath.Join(tmp, "a.json"), "a"), batchItem(filepath.Join(tmp, "b.json"), "b")})
	callNativeForCoverage(t, v, 文件, "原子写入组", batch)
	if a, err := os.ReadFile(filepath.Join(tmp, "a.json")); err != nil || string(a) != "a" {
		t.Fatalf("batch a: %q %v", a, err)
	}
	if _, re := callNativeForCoverage(t, v, 文件, "原子写入组", List([]Value{Int(1)})); re == nil {
		t.Fatal("invalid batch item accepted")
	}
	JSON, _ := StandardModule("标准.JSON", v)
	record := Record()
	record.Data.(*RecordObject).Order = []string{"a"}
	record.Data.(*RecordObject).Fields["a"] = Int(1)
	callNativeForCoverage(t, v, JSON, "解析", text("{\"a\":1}"))
	callNativeForCoverage(t, v, JSON, "序列化", record)
	callNativeForCoverage(t, v, JSON, "格式化", record)
	callNativeForCoverage(t, v, JSON, "解析", text("坏"))
	cycle := List(nil)
	cycle.Data.(*ListObject).Items = []Value{cycle}
	callNativeForCoverage(t, v, JSON, "序列化", cycle)
	时间, _ := StandardModule("标准.时间", v)
	callNativeForCoverage(t, v, 时间, "现在")
	callNativeForCoverage(t, v, 时间, "解析", text("2026-01-01"), text("2006-01-02"))
	callNativeForCoverage(t, v, 时间, "格式化", text("2026-01-01T00:00:00Z"), text("2006"))
	callNativeForCoverage(t, v, 时间, "日期差", text("2026-01-01T00:00:00Z"), text("2026-01-01T00:00:01Z"))
	callNativeForCoverage(t, v, 时间, "加秒", text("2026-01-01T00:00:00Z"), Int(1))
	数学, _ := StandardModule("标准.数学", v)
	callNativeForCoverage(t, v, 数学, "绝对值", Int(-1))
	callNativeForCoverage(t, v, 数学, "最小值", Int(1), Int(2))
	callNativeForCoverage(t, v, 数学, "最大值", Float(1), Int(2))
	callNativeForCoverage(t, v, 数学, "取整", Float(2.9))
	程序, _ := StandardModule("标准.程序", v)
	callNativeForCoverage(t, v, 程序, "参数")
	callNativeForCoverage(t, v, 程序, "环境")
	测试, _ := StandardModule("标准.测试", v)
	callNativeForCoverage(t, v, 测试, "断言相等", Int(1), Int(1))
	callNativeForCoverage(t, v, 测试, "断言错误", fn)
	callNativeForCoverage(t, v, 测试, "运行")
	list := List([]Value{Int(1), Int(2)})
	for _, name := range []string{"长度", "包含", "移除首项", "清空"} {
		method, _ := v.fieldGet(list, name, source.Span{})
		v.call(method, nil, source.Span{})
	}
	strMethod, _ := v.fieldGet(text("华言"), "长度", source.Span{})
	v.call(strMethod, nil, source.Span{})
	for _, name := range []string{"长度", "键", "值", "包含键", "条目"} {
		method, _ := v.fieldGet(d, name, source.Span{})
		v.call(method, nil, source.Span{})
	}
	console, _ := StandardModule("标准.控制台", v)
	callNativeForCoverage(t, v, console, "输出", text("x"))
	callNativeForCoverage(t, v, console, "错误输出", text("x"))
	callNativeForCoverage(t, v, console, "读取一行")
	for name, args := range map[string][]Value{"长度": {text("x")}, "类型": {Int(1)}, "转文字": {Int(1)}, "转整数": {text("1")}, "转小数": {text("1.5")}, "范围": {Int(1), Int(4)}, "错误": {text("e")}, "断言": {Bool(true)}} {
		fn, ok := v.globals.Get(name)
		if ok {
			v.call(fn, args, source.Span{})
		}
	}
}

func TestValueOperationsAndBoundaryErrors(t *testing.T) {
	v := New(&bytes.Buffer{}, strings.NewReader(""), nil)
	sp := source.Span{}
	for _, op := range []string{"+", "-", "*", "/", "%", "==", "!=", "<", "<=", ">", ">=", "且", "或"} {
		left, right := Int(4), Int(2)
		if op == "且" || op == "或" {
			left, right = Bool(true), Bool(false)
		}
		v.binary(op, left, right, sp)
	}
	v.binary("/", Int(1), Int(0), sp)
	v.binary("+", Text("x"), Int(1), sp)
	v.unary("非", Bool(true), sp)
	v.unary("-", Int(1), sp)
	v.unary("-", Text("x"), sp)
	list := List([]Value{Int(1), Int(2)})
	dict := Dict()
	setDict(dict, Text("x"), Int(3))
	rec := Record()
	rec.Data.(*RecordObject).Fields["x"] = Int(4)
	for _, pair := range []struct{ object, key Value }{{Text("华言"), Int(0)}, {list, Int(1)}, {dict, Text("x")}} {
		v.indexGet(pair.object, pair.key, sp)
	}
	v.indexGet(list, Int(9), sp)
	v.indexGet(Int(1), Int(0), sp)
	v.indexSet(list, Int(0), Int(8), sp)
	v.indexSet(dict, Text("y"), Int(9), sp)
	v.indexSet(Text("x"), Int(0), Int(1), sp)
	v.fieldGet(rec, "x", sp)
	v.fieldGet(rec, "no", sp)
	v.fieldGet(Int(1), "x", sp)
	v.fieldSet(rec, "y", Int(1), sp)
	v.fieldSet(Int(1), "x", Int(1), sp)
	for _, x := range []Value{list, Text("ab"), dict, Int(1)} {
		v.makeIterator(x, sp)
	}
	less(Int(1), Int(2))
	less(Text("a"), Text("b"))
	less(Bool(true), Bool(false))
	equal(Int(1), Float(1))
	equal(List(nil), List(nil))
}

func TestNumericJSONAndValueErrorBranches(t *testing.T) {
	v := New(&bytes.Buffer{}, strings.NewReader(""), nil)
	sp := source.Span{}
	for _, args := range [][3]any{{"+", int64(maxInt64), int64(1)}, {"-", int64(minInt64), int64(1)}, {"*", int64(minInt64), int64(-1)}, {"%", int64(1), int64(0)}, {"/", int64(1), int64(0)}, {"?", int64(1), int64(1)}} {
		v.intBinary(args[0].(string), args[1].(int64), args[2].(int64), sp)
	}
	v.unary("-", Int(minInt64), sp)
	v.unary("未知", Nil(), sp)
	for _, pair := range [][2]Value{{Text("a"), Text("b")}, {Bool(true), Bool(false)}, {Nil(), Nil()}} {
		v.binary("<", pair[0], pair[1], sp)
	}
	for _, x := range []Value{Bool(true), Int(1), Text("x"), Float(1), Nil(), List(nil)} {
		validKey(x)
	}
	fromJSON(nil)
	fromJSON(true)
	fromJSON("文字")
	fromJSON(json.Number("12"))
	fromJSON(json.Number("1.5"))
	fromJSON([]any{nil})
	fromJSON(map[string]any{"a": true})
	for _, x := range []Value{Nil(), Bool(true), Int(1), Float(1.5), Text("x"), List([]Value{Int(1)}), Dict(), Record(), Value{Kind: FunctionKind}} {
		toJSON(x, map[any]bool{})
	}
	marshalJSON(Value{Kind: FunctionKind}, false)
	decodeJSONValue(json.NewDecoder(strings.NewReader("[1")))
	minmax(v, nil, true)
	minmax(v, []Value{Text("x")}, true)
	less(Int(1), Text("x"))
}
