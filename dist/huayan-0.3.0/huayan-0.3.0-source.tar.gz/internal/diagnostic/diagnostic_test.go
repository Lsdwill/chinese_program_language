package diagnostic

import (
	"huayan/internal/source"
	"strings"
	"testing"
)

func TestFormatValidAndInvalidSpans(t *testing.T) {
	if got := (Diagnostic{Severity: Error, Code: "E1", Message: "坏"}).Format(); !strings.Contains(got, "错误 E1：坏") {
		t.Fatal(got)
	}
	f := &source.File{Name: "x.hua", Text: "甲\r乙"}
	got := (Diagnostic{Severity: Error, Code: "E2", Message: "错", Hint: "修复", Span: source.Span{File: f, Start: len("甲\r"), End: len("甲\r乙")}}).Format()
	if !strings.Contains(got, "x.hua:2:1") || !strings.Contains(got, "建议：修复") {
		t.Fatal(got)
	}
}
