# 华言 v0.3.0

华言（Huayan）是一门使用中文关键字的独立脚本语言。仓库包含 UTF-8 Lexer、递归下降/Pratt Parser、Resolver、局部槽位/Upvalue 字节码、栈式 VM、闭包、集合、记录、异常、模块、中文标准库和模块化图书馆示例。

## 运行

需要 Go 1.22 或更高版本：

```bash
go run ./cmd/huayan --version
go run ./cmd/huayan examples/你好世界.hua
go run ./cmd/huayan check examples/斐波那契.hua
go run ./cmd/huayan dis examples/斐波那契.hua
go run ./cmd/huayan test tests
go run ./cmd/huayan fmt --check examples/核心演示.hua
```

也可以构建独立解释器：

```bash
go build -o huayan ./cmd/huayan
./huayan examples/你好世界.hua
```

## 最小示例

```text
函数 阶乘(数字)
    如果 数字 <= 1
        返回 1
    结束
    返回 数字 * 阶乘(数字 - 1)
结束

打印(阶乘(5))
```

源文件使用 `.hua` 扩展名，也接受 `.华` 作为模块文件别名。语言实现位于 `internal/`，执行路径始终是：

```text
源文件 → Lexer → Parser → Resolver → 字节码 → VM
```

## 当前边界

已实现核心语言和常用标准模块；完整图书馆业务示例作为应用验证。尚未实现类、泛型、协程、包管理器、JIT 和数据库驱动，这些与开发计划中的第一版不做清单一致。

## 测试

```bash
go test ./...
go vet ./...
go test ./... -coverprofile=coverage.out
go tool cover -func=coverage.out
```

一致性案例位于 `tests/conformance/`，可直接运行：

```bash
go run ./cmd/huayan test tests/conformance
```
